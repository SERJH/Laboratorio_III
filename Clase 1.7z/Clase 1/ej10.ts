function checkString(cad : string) : void {

    let todoMayus : boolean = true;
    let todoMinus : boolean = true;

    for (let i = 0; i < cad.length; i++) {

        if (cad.substr(i,1) == cad.substr(i,1).toUpperCase()) {

            todoMinus = false;

        } else {

            todoMayus = false;

        }

    }

    if (todoMayus) {

        console.log("Todas mayusculas");

    } else if (todoMinus) {

        console.log("Todas minusculas");

    } else {

        console.log("Minusculas y mayusculas");

    }

}

checkString("atr");