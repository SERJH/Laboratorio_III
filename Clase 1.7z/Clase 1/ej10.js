"use strict";
function checkString(cad) {
    var todoMayus = true;
    var todoMinus = true;
    for (var i = 0; i < cad.length; i++) {
        if (cad.substr(i, 1) == cad.substr(i, 1).toUpperCase()) {
            todoMinus = false;
        }
        else {
            todoMayus = false;
        }
    }
    if (todoMayus) {
        console.log("Todas mayusculas");
    }
    else if (todoMinus) {
        console.log("Todas minusculas");
    }
    else {
        console.log("Minusculas y mayusculas");
    }
}
checkString("atr");
//# sourceMappingURL=ej10.js.map