function cube(num : number) : number {

    return num * cuadrado(num);

}

function cuadrado(num : number) : number {

    return num * num;

}

console.log(cube(10));