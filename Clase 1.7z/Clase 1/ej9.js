"use strict";
function factorial(num) {
    if (num == 1 || num == 0) {
        return 1;
    }
    else {
        return num * factorial(num - 1);
    }
}
function cube(num) {
    return num * cuadrado(num);
}
function cuadrado(num) {
    return num * num;
}
function ejercicioNueve(num) {
    var numero = 0;
    if (num > 0) {
        numero = factorial(num);
    }
    else if (num < 0) {
        numero = cube(num);
    }
    return numero;
}
console.log(ejercicioNueve(-5));
//# sourceMappingURL=ej9.js.map