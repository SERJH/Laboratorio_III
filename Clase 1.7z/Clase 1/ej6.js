"use strict";
function cube(num) {
    return num * cuadrado(num);
}
function cuadrado(num) {
    return num * num;
}
console.log(cube(10));
//# sourceMappingURL=ej6.js.map