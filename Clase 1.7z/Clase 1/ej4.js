"use strict";
function ejercicioCuatro(num) {
    var par = false;
    if (num % 2 == 0) {
        par = true;
    }
    if (par) {
        console.log("El numero " + num + " es par.");
    }
    else {
        console.log("El numero " + num + " es impar.");
    }
}
ejercicioCuatro(4);
//# sourceMappingURL=ej4.js.map