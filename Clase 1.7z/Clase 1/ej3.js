"use strict";
function ejercicioTres(num, cad) {
    if (cad != undefined) {
        for (var i = 0; i < num; i++) {
            console.log(cad);
        }
    }
    else {
        console.log(num * -1);
    }
}
ejercicioTres(3);
//# sourceMappingURL=ej3.js.map