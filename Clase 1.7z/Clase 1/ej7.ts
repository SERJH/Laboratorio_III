function firstTwentyPrimes() : void {

    let i;
    let contador = 0;

    for (i = 1; i > -1; i++) {

        if (isPrime(i)) {

            console.log(i);
            contador++;

            if (contador == 20) {

                break;

            }

        }

    }

}

function isPrime(num : number) : boolean {

    let divisores = 0;
    let prime = false;

    for (let i = 1; i <= num; i++) {

        if (num % i == 0) {

            divisores++;

        }

    }

    if (divisores == 2) {

        prime = true;

    }

    return prime;
}

firstTwentyPrimes();