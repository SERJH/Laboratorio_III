"use strict";
var año = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
for (var i = 0; i < año.length; i++) {
    console.log(i + 1 + ": " + año[i] + "\n");
}
//# sourceMappingURL=ej2.js.map