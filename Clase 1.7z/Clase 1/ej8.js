"use strict";
function factorial(num) {
    if (num == 1 || num == 0) {
        return 1;
    }
    else {
        return num * factorial(num - 1);
    }
}
console.log(factorial(6));
//# sourceMappingURL=ej8.js.map