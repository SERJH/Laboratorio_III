"use strict";
console.log("Hola mundo\nPuedo mostrar comillas \'simples\'\ny comillas \"dobles\"");
//# sourceMappingURL=ej1.js.map