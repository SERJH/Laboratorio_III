let nombre = "SANTIAGO";
let apellido = "Moran";

function MostrarNombreApellido(nombre : string, apellido : string) {

    apellido = apellido.toUpperCase();
    nombre = nombre.substr(0, 1).toUpperCase() + nombre.substr(1, nombre.length).toLowerCase();

    console.log(apellido + ", " + nombre);

}

MostrarNombreApellido(nombre, apellido);