"use strict";
function firstTwentyPrimes() {
    var i;
    var contador = 0;
    for (i = 1; i > -1; i++) {
        if (isPrime(i)) {
            console.log(i);
            contador++;
            if (contador == 20) {
                break;
            }
        }
    }
}
function isPrime(num) {
    var divisores = 0;
    var prime = false;
    for (var i = 1; i <= num; i++) {
        if (num % i == 0) {
            divisores++;
        }
    }
    if (divisores == 2) {
        prime = true;
    }
    return prime;
}
firstTwentyPrimes();
//# sourceMappingURL=ej7.js.map