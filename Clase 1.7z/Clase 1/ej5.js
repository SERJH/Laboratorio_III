"use strict";
var nombre = "SANTIAGO";
var apellido = "Moran";
function MostrarNombreApellido(nombre, apellido) {
    apellido = apellido.toUpperCase();
    nombre = nombre.substr(0, 1).toUpperCase() + nombre.substr(1, nombre.length).toLowerCase();
    console.log(apellido + ", " + nombre);
}
MostrarNombreApellido(nombre, apellido);
//# sourceMappingURL=ej5.js.map