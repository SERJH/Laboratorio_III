function ejercicioCuatro(num : number) : void {

    let par : boolean = false;

    if (num % 2 == 0) {

        par = true;

    }

    if (par) {

        console.log("El numero " + num + " es par.");

    } else {

        console.log("El numero " + num + " es impar.");

    }

}

ejercicioCuatro(4);