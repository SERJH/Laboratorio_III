function ejercicioTres(num : number, cad? : string) : void {

    if (cad != undefined) {

        for (let i = 0; i < num; i++) {

            console.log(cad);

        }

    } else {

        console.log(num * - 1);

    }

}

ejercicioTres(3);