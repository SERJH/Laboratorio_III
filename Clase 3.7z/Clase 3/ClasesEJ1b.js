"use strict";
/// <reference path = "./ClasesEJ1.ts" />
var Clases;
(function (Clases) {
    var Rectangulo = /** @class */ (function () {
        function Rectangulo(v1, v3) {
            this._verticeUno = v1;
            this._verticeTres = v3;
            this._verticeDos = new Clases.Punto(v3.GetX(), v1.GetY());
            this._verticeCuatro = new Clases.Punto(v1.GetX(), v3.GetY());
            this._base = this._verticeTres.GetX() - this._verticeCuatro.GetX();
            this._altura = this._verticeUno.GetY() - this._verticeCuatro.GetY();
            this._area = this._base * this._altura;
            this._perimetro = ((this._base * 2) + (this._altura * 2));
        }
        Rectangulo.prototype.GetArea = function () {
            return this._area;
        };
        Rectangulo.prototype.GetPerimetro = function () {
            return this._perimetro;
        };
        Rectangulo.prototype.ToString = function () {
            var retorno = "";
            retorno += "Vertice 1: [" + this._verticeUno.GetX() + ", " + this._verticeUno.GetY() + "]\n";
            retorno += "Vertice 2: [" + this._verticeDos.GetX() + ", " + this._verticeDos.GetY() + "]\n";
            retorno += "Vertice 3: [" + this._verticeTres.GetX() + ", " + this._verticeTres.GetY() + "]\n";
            retorno += "Vertice 4: [" + this._verticeCuatro.GetX() + ", " + this._verticeCuatro.GetY() + "]\n";
            retorno += "Base: " + this._base + "\n";
            retorno += "Altura: " + this._altura + "\n";
            retorno += "Perimetro: " + this._perimetro + "\n";
            retorno += "Area: " + this._area + "\n";
            return retorno;
        };
        return Rectangulo;
    }());
    Clases.Rectangulo = Rectangulo;
})(Clases || (Clases = {}));
//# sourceMappingURL=ClasesEJ1b.js.map