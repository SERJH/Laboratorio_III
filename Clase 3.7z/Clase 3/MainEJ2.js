"use strict";
/// <reference path = "./ClasesEJ2.ts" /> 
//# sourceMappingURL=MainEJ2.js.map