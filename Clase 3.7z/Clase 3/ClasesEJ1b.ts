/// <reference path = "./ClasesEJ1.ts" />

namespace Clases {

    export class Rectangulo {

        private _area : number;
        private _base : number;
        private _altura : number;
        private _perimetro : number;
        private _verticeUno : Punto;
        private _verticeDos : Punto;
        private _verticeTres : Punto;
        private _verticeCuatro : Punto;
    
        public constructor(v1 : Punto, v3: Punto) {
    
            this._verticeUno = v1;
            this._verticeTres = v3;
    
            this._verticeDos = new Punto(v3.GetX(), v1.GetY());
            this._verticeCuatro = new Punto(v1.GetX(), v3.GetY());
    
            this._base = this._verticeTres.GetX() - this._verticeCuatro.GetX();
            this._altura = this._verticeUno.GetY() - this._verticeCuatro.GetY();
    
            this._area = this._base * this._altura;
            this._perimetro = ((this._base * 2) + (this._altura * 2));
    
        }
    
        public GetArea() : number {
    
            return this._area;
     
        }
    
        public GetPerimetro() : number {
    
            return this._perimetro;
    
        }
    
        public ToString() : string {
    
            let retorno : string = "";
    
            retorno += "Vertice 1: [" + this._verticeUno.GetX() + ", " + this._verticeUno.GetY() + "]\n";
            retorno += "Vertice 2: [" + this._verticeDos.GetX() + ", " + this._verticeDos.GetY() + "]\n";
            retorno += "Vertice 3: [" + this._verticeTres.GetX() + ", " + this._verticeTres.GetY() + "]\n";
            retorno += "Vertice 4: [" + this._verticeCuatro.GetX() + ", " + this._verticeCuatro.GetY() + "]\n";
            retorno += "Base: " + this._base + "\n";
            retorno += "Altura: " + this._altura + "\n";
            retorno += "Perimetro: " + this._perimetro + "\n";
            retorno += "Area: " + this._area + "\n";
    
            return retorno;
    
        }
    
    }

}