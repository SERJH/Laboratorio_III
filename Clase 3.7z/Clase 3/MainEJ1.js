"use strict";
/// <reference path = "./ClasesEJ1b.ts" />
var p1 = new Clases.Punto(1, 7);
var p3 = new Clases.Punto(3, 2);
var rect = new Clases.Rectangulo(p1, p3);
console.log(rect.ToString());
//# sourceMappingURL=MainEJ1.js.map