import {Auto} from "./01_clases";

let a1 = new Auto("ROJO",120500);

console.log(a1.color);
console.log(a1.GetPrecio());

Auto.MetodoEstatico();
console.log("fin...!!");