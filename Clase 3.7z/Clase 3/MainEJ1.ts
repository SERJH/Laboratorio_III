/// <reference path = "./ClasesEJ1b.ts" />

let p1 = new Clases.Punto(1, 7);
let p3 = new Clases.Punto(3, 2);

let rect = new Clases.Rectangulo(p1, p3);

console.log(rect.ToString());