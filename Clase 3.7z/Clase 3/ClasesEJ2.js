"use strict";
/// <reference path = "./ClasesEJ1b.ts" />
var Clases;
(function (Clases) {
    var FiguraGeometrica = /** @class */ (function () {
        function FiguraGeometrica(color) {
            this._color = color;
        }
        FiguraGeometrica.prototype.GetColor = function () {
            return this._color;
        };
        FiguraGeometrica.prototype.ToString = function () {
            return "Color: " + this._color + "\n";
        };
        return FiguraGeometrica;
    }());
})(Clases || (Clases = {}));
//# sourceMappingURL=ClasesEJ2.js.map