/// <reference path = "./ClasesEJ1b.ts" />

namespace Clases {

    abstract class FiguraGeometrica {

        protected _color : string;
        protected _perimetro : number;
        protected _superficie : number;
    
        public constructor(color : string) {
    
            this._color = color;
    
        }
    
        public GetColor() : string {
    
            return this._color;
    
        }
    
        public ToString() : string {
    
            return "Color: " + this._color + "\n";
    
        }
    
        public abstract Dibujar() : string;
        protected abstract CalcularDatos() : void;
    
    }

}

