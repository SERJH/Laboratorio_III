"use strict";
var EJ04;
(function (EJ04) {
    function APP4() {
        var xhttp = new XMLHttpRequest();
        var productos = [
            { codigoBarra: 100101, nombre: "Atun carlitos", precio: 5 },
            { codigoBarra: 153268, nombre: "Chococrispis", precio: 17 },
            { codigoBarra: 107771, nombre: "Mayonesa natura 1lt", precio: 70 }
        ];
        xhttp.open("POST", "./mostrarColeccionJson.php", true);
        xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhttp.send("productoUno=" + JSON.stringify(productos[0]) + "," +
            "productoDos=" + JSON.stringify(productos[1]) + "," +
            "productoTres=" + JSON.stringify(productos[2]));
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                var div = document.getElementById("mostrarDiv");
                div.innerHTML = xhttp.responseText;
            }
        };
    }
    EJ04.APP4 = APP4;
})(EJ04 || (EJ04 = {}));
EJ04.APP4();
//# sourceMappingURL=EJ04.js.map