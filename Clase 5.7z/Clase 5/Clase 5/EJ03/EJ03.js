"use strict";
var EJ03;
(function (EJ03) {
    function APP3() {
        var xhttp = new XMLHttpRequest();
        var producto = { codigoBarra: 100101, nombre: "Atun carlitos", precio: 5 };
        xhttp.open("POST", "./mostrarJson.php", true);
        xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhttp.send("producto=" + JSON.stringify(producto));
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                var div = document.getElementById("mostrarDiv");
                div.innerHTML = xhttp.responseText;
            }
        };
    }
    EJ03.APP3 = APP3;
})(EJ03 || (EJ03 = {}));
EJ03.APP3();
//# sourceMappingURL=EJ03.js.map