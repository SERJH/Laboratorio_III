<?php

var_dump($_POST);

$producto = json_decode($_POST["producto"]);
var_dump($producto);
echo "<br>" . $producto->nombre . "<br>";
echo $producto->precio . "<br>";
echo $producto->codigoBarra;

?>