namespace EJ03 {

    export function APP3() {

        let xhttp = new XMLHttpRequest();
        
        let producto = {codigoBarra : 100101, nombre : "Atun carlitos", precio : 5};

        xhttp.open("POST", "./mostrarJson.php", true);
        xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
        xhttp.send("producto=" + JSON.stringify(producto));

        xhttp.onreadystatechange = function() {

            if (xhttp.readyState == 4 && xhttp.status == 200) {

                let div = (<HTMLDivElement> document.getElementById("mostrarDiv"));

                div.innerHTML = xhttp.responseText;

            }
        }

    }

}



EJ03.APP3();