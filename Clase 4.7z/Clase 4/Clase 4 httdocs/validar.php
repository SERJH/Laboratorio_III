<?php

if (isset($_GET["txtUsuario"]) && isset($_GET["txtPass"])) {

    $usuario = $_GET["txtUsuario"];
    $password = $_GET["txtPass"];

    $archivo = fopen("./usuarios.txt", "r");

    $encontro = false;

    while (!feof($archivo)) {

        $linea = fgets($archivo);
        $datosUsuario = explode(" - ", $linea);

        $user = $datosUsuario[0];
        $pass = $datosUsuario[1];

        if ($user == $usuario && $pass == $password) {

            $encontro = true;

        }

    }

}