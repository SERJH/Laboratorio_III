"use strict";
var clase4;
(function (clase4) {
    var xhttp = new XMLHttpRequest();
    function ValidarUsuarioGET() {
        var usuario = document.getElementById("txtUsuario").value;
        var pass = document.getElementById("txtPass").value;
        xhttp.open("GET", "./validar.php?txtUsuario=" + usuario + "&txtPass=" + pass, true);
        xhttp.send();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                if (xhttp.responseText == "ok") {
                    var body = document.getElementById("body");
                    body.style.backgroundColor = "green";
                    var wow = document.getElementById("wow");
                    wow.style.display = "inline";
                }
                else {
                    var body = document.getElementById("body");
                    body.style.backgroundColor = "red";
                }
            }
        };
    }
    clase4.ValidarUsuarioGET = ValidarUsuarioGET;
    function ValidarUsuarioPOST() {
        var usuario = document.getElementById("txtUsuario").value;
        var pass = document.getElementById("txtPass").value;
        xhttp.open("GET", "./validar.php", true);
        xhttp.send();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                alert(xhttp.responseText);
            }
        };
    }
    clase4.ValidarUsuarioPOST = ValidarUsuarioPOST;
})(clase4 || (clase4 = {}));
//# sourceMappingURL=validaciones.js.map