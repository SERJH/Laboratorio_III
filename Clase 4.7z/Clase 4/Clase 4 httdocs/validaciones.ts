namespace clase4 {

    let xhttp : XMLHttpRequest = new XMLHttpRequest();

    export function ValidarUsuarioGET() : void {

        let usuario : string = (<HTMLInputElement> document.getElementById("txtUsuario")).value;
        let pass : string = (<HTMLInputElement> document.getElementById("txtPass")).value;

        xhttp.open("GET", "./validar.php?txtUsuario="+usuario+"&txtPass="+pass, true);

        xhttp.send();

        xhttp.onreadystatechange = () => {

            if (xhttp.readyState == 4 && xhttp.status == 200) {

                if (xhttp.responseText == "ok") {

                    let body = (<HTMLBodyElement> document.getElementById("body"));
                    body.style.backgroundColor = "green";

                    let wow = (<HTMLImageElement> document.getElementById("wow"));
                    wow.style.display = "inline";


                } else {

                    let body = (<HTMLBodyElement> document.getElementById("body"));
                    body.style.backgroundColor = "red";

                }

            }

        }

    }

    export function ValidarUsuarioPOST() : void {

        let usuario : string = (<HTMLInputElement> document.getElementById("txtUsuario")).value;
        let pass : string = (<HTMLInputElement> document.getElementById("txtPass")).value;

        xhttp.open("GET", "./validar.php", true);

        xhttp.send();

        xhttp.onreadystatechange = () => {

            if (xhttp.readyState == 4 && xhttp.status == 200) {

                alert(xhttp.responseText);

            }

        }

    }

}